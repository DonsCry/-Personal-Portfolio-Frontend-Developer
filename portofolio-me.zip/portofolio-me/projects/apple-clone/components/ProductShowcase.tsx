'use client'

import { motion } from 'framer-motion'

const products = [
  {
    id: 1,
    name: 'MacBook Pro',
    emoji: '💻',
    description: 'Supercharged by M3, M3 Pro, or M3 Max',
  },
  {
    id: 2,
    name: 'iPad Pro',
    emoji: '📱',
    description: 'Impossibly thin. Impossibly powerful.',
  },
  {
    id: 3,
    name: 'Apple Watch',
    emoji: '⌚',
    description: 'The ultimate device for a healthy life.',
  },
  {
    id: 4,
    name: 'AirPods Pro',
    emoji: '🎧',
    description: 'Adaptive Audio. Personalized.',
  },
]

export function ProductShowcase() {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  }

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.5 },
    },
  }

  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8 bg-gray-50">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="mb-16"
        >
          <h2 className="text-5xl font-bold text-black mb-4">Explore the lineup</h2>
          <p className="text-xl text-gray-600">
            Discover the full range of innovative Apple products.
          </p>
        </motion.div>

        <motion.div
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6"
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
        >
          {products.map((product) => (
            <motion.div
              key={product.id}
              variants={itemVariants}
              className="bg-white rounded-2xl p-8 text-center hover:shadow-xl transition-all duration-300 cursor-pointer group"
              whileHover={{ y: -8 }}
            >
              <div className="text-6xl mb-4 group-hover:scale-110 transition-transform">
                {product.emoji}
              </div>
              <h3 className="text-2xl font-bold text-black mb-2">{product.name}</h3>
              <p className="text-gray-600 mb-6">{product.description}</p>
              <motion.a
                href="#"
                className="text-blue-600 font-semibold hover:text-blue-700 transition-colors"
                whileHover={{ x: 4 }}
              >
                Learn more →
              </motion.a>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  )
}
