'use client'

import { motion } from 'framer-motion'

export function Hero() {
  return (
    <section className="relative bg-black text-white py-32 px-4 sm:px-6 lg:px-8 overflow-hidden">
      <motion.div
        className="max-w-4xl mx-auto text-center"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
      >
        <motion.div
          animate={{ y: [0, -10, 0] }}
          transition={{ duration: 3, repeat: Infinity }}
          className="text-7xl sm:text-8xl font-bold mb-6"
        >
          iPhone 15
        </motion.div>
        <p className="text-2xl text-gray-300 mb-8">
          Powerful. Colorful. Wonderful.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <motion.button
            className="px-8 py-4 bg-white text-black font-bold rounded-full hover:bg-gray-200 transition-colors"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            Learn more
          </motion.button>
          <motion.button
            className="px-8 py-4 border-2 border-white text-white font-bold rounded-full hover:bg-white/10 transition-colors"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            Buy
          </motion.button>
        </div>
      </motion.div>
    </section>
  )
}
