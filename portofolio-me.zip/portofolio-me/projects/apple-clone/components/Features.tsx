'use client'

import { motion } from 'framer-motion'
import { Zap, Shield, Smartphone, Cpu } from 'lucide-react'

const features = [
  {
    icon: Zap,
    title: 'Lightning Fast',
    description: 'Powered by the latest Apple silicon for incredible performance.',
  },
  {
    icon: Shield,
    title: 'Privacy First',
    description: 'Your data is encrypted and stays on your device.',
  },
  {
    icon: Smartphone,
    title: 'Seamlessly Connected',
    description: 'All your devices work together effortlessly.',
  },
  {
    icon: Cpu,
    title: 'AI Integration',
    description: 'Smart features that learn and adapt to you.',
  },
]

export function Features() {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.15,
      },
    },
  }

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.5 },
    },
  }

  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8 bg-white">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="mb-16 text-center"
        >
          <h2 className="text-5xl font-bold text-black mb-4">Why Apple</h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Innovation at the intersection of technology and humanity.
          </p>
        </motion.div>

        <motion.div
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8"
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
        >
          {features.map((feature, index) => {
            const Icon = feature.icon
            return (
              <motion.div
                key={index}
                variants={itemVariants}
                className="text-center"
              >
                <motion.div
                  className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-gray-100 mb-4"
                  whileHover={{ scale: 1.1, rotate: 5 }}
                >
                  <Icon size={32} className="text-black" />
                </motion.div>
                <h3 className="text-xl font-bold text-black mb-2">
                  {feature.title}
                </h3>
                <p className="text-gray-600">{feature.description}</p>
              </motion.div>
            )
          })}
        </motion.div>
      </div>
    </section>
  )
}
