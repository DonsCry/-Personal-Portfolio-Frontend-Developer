'use client'

import { motion } from 'framer-motion'
import { Star, MapPin } from 'lucide-react'

const destinations = [
  {
    id: 1,
    name: 'Paris, France',
    image: '🗼',
    rating: 4.8,
    reviews: 2543,
    price: '$899',
    description: 'City of lights and romance',
  },
  {
    id: 2,
    name: 'Tokyo, Japan',
    image: '🗾',
    rating: 4.9,
    reviews: 1876,
    price: '$1,299',
    description: 'Modern meets tradition',
  },
  {
    id: 3,
    name: 'Bali, Indonesia',
    image: '🏝️',
    rating: 4.7,
    reviews: 3421,
    price: '$599',
    description: 'Tropical paradise',
  },
  {
    id: 4,
    name: 'New York, USA',
    image: '🗽',
    rating: 4.6,
    reviews: 4102,
    price: '$699',
    description: 'The city that never sleeps',
  },
]

export function FeaturedDestinations() {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  }

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.5 },
    },
  }

  return (
    <section className="py-16 px-4 sm:px-6 lg:px-8 bg-white">
      <div className="max-w-6xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="mb-12"
        >
          <h2 className="text-4xl font-bold text-gray-900 mb-2">Featured Destinations</h2>
          <p className="text-gray-600">Explore our most popular travel destinations</p>
        </motion.div>

        <motion.div
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6"
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
        >
          {destinations.map((dest) => (
            <motion.div
              key={dest.id}
              variants={itemVariants}
              className="bg-white rounded-lg overflow-hidden shadow-md hover:shadow-xl transition-all duration-300 cursor-pointer group"
              whileHover={{ y: -8 }}
            >
              {/* Image */}
              <div className="h-48 bg-gradient-to-br from-blue-400 to-blue-600 flex items-center justify-center text-6xl group-hover:scale-110 transition-transform">
                {dest.image}
              </div>

              {/* Content */}
              <div className="p-4">
                <h3 className="text-lg font-bold text-gray-900 mb-1">{dest.name}</h3>
                <p className="text-sm text-gray-600 mb-3">{dest.description}</p>

                {/* Rating */}
                <div className="flex items-center gap-1 mb-3">
                  <div className="flex gap-0.5">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        size={16}
                        className={i < Math.floor(dest.rating) ? 'fill-yellow-400 text-yellow-400' : 'text-gray-300'}
                      />
                    ))}
                  </div>
                  <span className="text-sm text-gray-600">({dest.reviews})</span>
                </div>

                {/* Price and Button */}
                <div className="flex justify-between items-center">
                  <span className="text-xl font-bold text-primary">{dest.price}</span>
                  <motion.button
                    className="px-4 py-2 bg-primary text-white font-semibold rounded hover:bg-blue-700 transition-colors"
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    Book
                  </motion.button>
                </div>
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  )
}
