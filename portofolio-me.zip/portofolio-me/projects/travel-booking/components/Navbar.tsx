'use client'

import { motion } from 'framer-motion'
import { Plane, Menu, X } from 'lucide-react'
import { useState } from 'react'

export function Navbar() {
  const [isOpen, setIsOpen] = useState(false)

  return (
    <motion.nav
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.5 }}
      className="sticky top-0 z-50 bg-white border-b border-gray-200"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <motion.div
            className="flex items-center gap-2 text-2xl font-bold text-primary"
            whileHover={{ scale: 1.05 }}
          >
            <Plane size={28} />
            <span>TravelHub</span>
          </motion.div>

          {/* Desktop Menu */}
          <div className="hidden md:flex gap-8">
            <a href="#" className="text-gray-700 hover:text-primary transition-colors">
              Flights
            </a>
            <a href="#" className="text-gray-700 hover:text-primary transition-colors">
              Hotels
            </a>
            <a href="#" className="text-gray-700 hover:text-primary transition-colors">
              Experiences
            </a>
            <a href="#" className="text-gray-700 hover:text-primary transition-colors">
              Deals
            </a>
          </div>

          {/* CTA Button */}
          <motion.button
            className="hidden md:block px-6 py-2 bg-primary text-white font-semibold rounded-lg hover:bg-blue-700 transition-colors"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            Sign In
          </motion.button>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden"
            onClick={() => setIsOpen(!isOpen)}
          >
            {isOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile Menu */}
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="md:hidden pb-4 space-y-2"
          >
            <a href="#" className="block px-4 py-2 text-gray-700 hover:bg-gray-100 rounded">
              Flights
            </a>
            <a href="#" className="block px-4 py-2 text-gray-700 hover:bg-gray-100 rounded">
              Hotels
            </a>
            <a href="#" className="block px-4 py-2 text-gray-700 hover:bg-gray-100 rounded">
              Experiences
            </a>
            <a href="#" className="block px-4 py-2 text-gray-700 hover:bg-gray-100 rounded">
              Deals
            </a>
            <button className="w-full px-4 py-2 bg-primary text-white font-semibold rounded hover:bg-blue-700">
              Sign In
            </button>
          </motion.div>
        )}
      </div>
    </motion.nav>
  )
}
