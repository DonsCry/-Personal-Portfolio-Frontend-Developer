'use client'

import { motion } from 'framer-motion'

export function Hero() {
  return (
    <section className="relative bg-gradient-to-r from-blue-500 to-blue-600 text-white py-20 px-4 sm:px-6 lg:px-8">
      <motion.div
        className="max-w-4xl mx-auto text-center"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
      >
        <h1 className="text-5xl sm:text-6xl font-bold mb-4">
          Discover Your Next Adventure
        </h1>
        <p className="text-xl text-blue-100 mb-8">
          Find the best flights, hotels, and experiences at unbeatable prices
        </p>
        <motion.button
          className="px-8 py-4 bg-accent text-white font-bold rounded-lg hover:bg-red-600 transition-colors text-lg"
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
        >
          Start Exploring
        </motion.button>
      </motion.div>
    </section>
  )
}
