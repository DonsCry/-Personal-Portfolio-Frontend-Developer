'use client'

import { motion } from 'framer-motion'
import { MapPin, Calendar, Users, Search } from 'lucide-react'
import { useState } from 'react'

export function SearchPanel() {
  const [tripType, setTripType] = useState('roundtrip')

  return (
    <section className="bg-secondary py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-6xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="bg-white rounded-lg shadow-lg p-6"
        >
          {/* Trip Type Selection */}
          <div className="flex gap-6 mb-6">
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="radio"
                value="roundtrip"
                checked={tripType === 'roundtrip'}
                onChange={(e) => setTripType(e.target.value)}
                className="w-4 h-4"
              />
              <span className="text-gray-700">Round Trip</span>
            </label>
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="radio"
                value="oneway"
                checked={tripType === 'oneway'}
                onChange={(e) => setTripType(e.target.value)}
                className="w-4 h-4"
              />
              <span className="text-gray-700">One Way</span>
            </label>
          </div>

          {/* Search Fields */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {/* From */}
            <motion.div
              whileHover={{ y: -2 }}
              className="relative"
            >
              <label className="block text-sm font-semibold text-gray-700 mb-2">From</label>
              <div className="flex items-center gap-2 border border-gray-300 rounded-lg px-4 py-3 hover:border-primary transition-colors">
                <MapPin size={20} className="text-primary" />
                <input
                  type="text"
                  placeholder="Departure city"
                  className="flex-1 outline-none text-gray-700"
                />
              </div>
            </motion.div>

            {/* To */}
            <motion.div
              whileHover={{ y: -2 }}
              className="relative"
            >
              <label className="block text-sm font-semibold text-gray-700 mb-2">To</label>
              <div className="flex items-center gap-2 border border-gray-300 rounded-lg px-4 py-3 hover:border-primary transition-colors">
                <MapPin size={20} className="text-primary" />
                <input
                  type="text"
                  placeholder="Destination city"
                  className="flex-1 outline-none text-gray-700"
                />
              </div>
            </motion.div>

            {/* Departure Date */}
            <motion.div
              whileHover={{ y: -2 }}
              className="relative"
            >
              <label className="block text-sm font-semibold text-gray-700 mb-2">Departure</label>
              <div className="flex items-center gap-2 border border-gray-300 rounded-lg px-4 py-3 hover:border-primary transition-colors">
                <Calendar size={20} className="text-primary" />
                <input
                  type="date"
                  className="flex-1 outline-none text-gray-700"
                />
              </div>
            </motion.div>

            {/* Passengers */}
            <motion.div
              whileHover={{ y: -2 }}
              className="relative"
            >
              <label className="block text-sm font-semibold text-gray-700 mb-2">Passengers</label>
              <div className="flex items-center gap-2 border border-gray-300 rounded-lg px-4 py-3 hover:border-primary transition-colors">
                <Users size={20} className="text-primary" />
                <select className="flex-1 outline-none text-gray-700 bg-white">
                  <option>1 Passenger</option>
                  <option>2 Passengers</option>
                  <option>3 Passengers</option>
                  <option>4+ Passengers</option>
                </select>
              </div>
            </motion.div>
          </div>

          {/* Search Button */}
          <motion.button
            className="w-full mt-6 px-6 py-3 bg-primary text-white font-bold rounded-lg hover:bg-blue-700 transition-colors flex items-center justify-center gap-2"
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
          >
            <Search size={20} />
            Search Flights
          </motion.button>
        </motion.div>
      </div>
    </section>
  )
}
