'use client'

import { motion } from 'framer-motion'
import { TrendingUp, Clock } from 'lucide-react'

const deals = [
  {
    id: 1,
    title: 'Summer Escape to Greece',
    discount: '-40%',
    originalPrice: '$1,299',
    finalPrice: '$779',
    duration: '7 days',
    image: '🏖️',
  },
  {
    id: 2,
    title: 'European Grand Tour',
    discount: '-35%',
    originalPrice: '$2,499',
    finalPrice: '$1,624',
    duration: '14 days',
    image: '🚂',
  },
  {
    id: 3,
    title: 'Adventure in Peru',
    discount: '-30%',
    originalPrice: '$1,599',
    finalPrice: '$1,119',
    duration: '10 days',
    image: '🏔️',
  },
]

export function PopularDeals() {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.15,
      },
    },
  }

  const itemVariants = {
    hidden: { opacity: 0, x: -20 },
    visible: {
      opacity: 1,
      x: 0,
      transition: { duration: 0.5 },
    },
  }

  return (
    <section className="py-16 px-4 sm:px-6 lg:px-8 bg-secondary">
      <div className="max-w-6xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="mb-12"
        >
          <div className="flex items-center gap-2 mb-2">
            <TrendingUp size={24} className="text-accent" />
            <h2 className="text-4xl font-bold text-gray-900">Hot Deals</h2>
          </div>
          <p className="text-gray-600">Limited time offers on amazing packages</p>
        </motion.div>

        <motion.div
          className="grid grid-cols-1 md:grid-cols-3 gap-6"
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
        >
          {deals.map((deal) => (
            <motion.div
              key={deal.id}
              variants={itemVariants}
              className="bg-white rounded-lg overflow-hidden shadow-md hover:shadow-xl transition-all duration-300"
              whileHover={{ y: -8 }}
            >
              {/* Image with Discount Badge */}
              <div className="relative h-40 bg-gradient-to-br from-red-400 to-red-600 flex items-center justify-center text-5xl">
                {deal.image}
                <div className="absolute top-4 right-4 bg-accent text-white px-3 py-1 rounded-full font-bold text-lg">
                  {deal.discount}
                </div>
              </div>

              {/* Content */}
              <div className="p-6">
                <h3 className="text-lg font-bold text-gray-900 mb-2">{deal.title}</h3>

                {/* Duration */}
                <div className="flex items-center gap-2 text-gray-600 mb-4">
                  <Clock size={16} />
                  <span className="text-sm">{deal.duration}</span>
                </div>

                {/* Pricing */}
                <div className="mb-4">
                  <p className="text-sm text-gray-500 line-through">{deal.originalPrice}</p>
                  <p className="text-3xl font-bold text-primary">{deal.finalPrice}</p>
                </div>

                {/* Button */}
                <motion.button
                  className="w-full px-4 py-3 bg-accent text-white font-bold rounded-lg hover:bg-red-600 transition-colors"
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  Claim Deal
                </motion.button>
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  )
}
