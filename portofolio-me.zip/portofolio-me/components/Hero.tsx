'use client'

import { motion } from 'framer-motion'
import { Github, Linkedin, Mail, ExternalLink } from 'lucide-react'
import Image from 'next/image'

export function Hero() {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
        delayChildren: 0.3,
      },
    },
  }

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.8, ease: 'easeOut' },
    },
  }

  return (
    <section className="min-h-screen flex items-center justify-center pt-20 px-4 sm:px-6 lg:px-8">
      <motion.div
        className="max-w-5xl mx-auto"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        {/* Profile Section */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center mb-12">
          {/* Photo */}
          <motion.div
            variants={itemVariants}
            className="flex justify-center md:justify-end"
          >
            <div className="relative group">
              <div className="absolute inset-0 bg-gradient-to-br from-accent to-blue-400 rounded-2xl blur-2xl opacity-50 group-hover:opacity-75 transition-opacity"></div>
              <div className="relative w-64 h-80 rounded-2xl overflow-hidden shadow-2xl hover:shadow-accent/50 transition-all duration-300 border border-accent/20">
                <Image
                  src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=500&fit=crop"
                  alt="Bernard Tando - Frontend Developer"
                  fill
                  className="object-cover object-center"
                  priority
                  quality={100}
                  sizes="(max-width: 768px) 100vw, 256px"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/30 to-transparent"></div>
              </div>
            </div>
          </motion.div>

          {/* Text Content */}
          <motion.div
            variants={itemVariants}
            className="text-center md:text-left"
          >
            {/* Headline */}
            <motion.h1
              variants={itemVariants}
              className="text-5xl sm:text-6xl font-bold mb-4 leading-tight"
            >
              Frontend <span className="bg-gradient-to-r from-accent to-blue-400 bg-clip-text text-transparent">UI Developer</span>
            </motion.h1>

            {/* Quote */}
            <motion.div
              variants={itemVariants}
              className="mb-6 p-6 border-l-4 border-accent bg-dark-secondary/50 rounded-lg"
            >
              <p className="text-lg italic text-accent mb-2">
                "Code is poetry, design is emotion, and together they create magic."
              </p>
              <p className="text-sm text-gray-400">
                — Bernard Tando
              </p>
            </motion.div>

            {/* Subtitle */}
            <motion.p
              variants={itemVariants}
              className="text-lg text-gray-400 mb-8"
            >
              Crafting beautiful, responsive interfaces with React, Next.js, and Tailwind CSS. Turning designs into pixel-perfect code.
            </motion.p>
          </motion.div>
        </div>

        {/* CTA Buttons */}
        <motion.div
          variants={itemVariants}
          className="flex flex-col sm:flex-row gap-4 justify-center md:justify-start mb-12"
        >
          <motion.a
            href="#contact"
            className="px-8 py-4 bg-accent text-dark font-semibold rounded-lg hover:bg-blue-400 transition-colors"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            Hire Me
          </motion.a>
          <motion.a
            href="https://github.com"
            target="_blank"
            rel="noopener noreferrer"
            className="px-8 py-4 border border-accent text-accent font-semibold rounded-lg hover:bg-accent/10 transition-colors flex items-center justify-center gap-2"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <Github size={20} /> GitHub
          </motion.a>
        </motion.div>

        {/* Social Links */}
        <motion.div
          variants={itemVariants}
          className="flex justify-center gap-6"
        >
          <motion.a
            href="https://github.com/DonsCry"
            target="_blank"
            rel="noopener noreferrer"
            className="text-gray-400 hover:text-accent transition-colors"
            whileHover={{ y: -3 }}
          >
            <Github size={28} />
          </motion.a>
          <motion.a
            href="https://www.linkedin.com/in/bernard-tando-23504a393/"
            target="_blank"
            rel="noopener noreferrer"
            className="text-gray-400 hover:text-accent transition-colors"
            whileHover={{ y: -3 }}
          >
            <Linkedin size={28} />
          </motion.a>
          <motion.a
            href="mailto:revalsaputra350@gmail.com"
            className="text-gray-400 hover:text-accent transition-colors"
            whileHover={{ y: -3 }}
          >
            <Mail size={28} />
          </motion.a>
        </motion.div>

        {/* Scroll Indicator */}
        <motion.div
          animate={{ y: [0, 10, 0] }}
          transition={{ duration: 2, repeat: Infinity }}
          className="mt-16"
        >
          <div className="text-gray-400 text-sm">Scroll to explore</div>
        </motion.div>
      </motion.div>
    </section>
  )
}
