'use client'

import { motion } from 'framer-motion'
import { ExternalLink, Github } from 'lucide-react'

const projects = [
  {
    id: 1,
    title: 'E-Commerce Platform',
    description: 'Full-featured e-commerce platform with product filtering, cart management, and checkout flow.',
    role: 'Frontend Developer',
    tech: ['React', 'Next.js', 'Tailwind CSS', 'Stripe API'],
    image: '🛍️',
    demo: '#',
    github: '#',
  },
  {
    id: 2,
    title: 'Task Management App',
    description: 'Real-time collaborative task management with drag-and-drop, notifications, and team features.',
    role: 'Full Stack Developer',
    tech: ['Next.js', 'TypeScript', 'Tailwind', 'Firebase'],
    image: '✅',
    demo: '#',
    github: '#',
  },
  {
    id: 3,
    title: 'Analytics Dashboard',
    description: 'Interactive analytics dashboard with real-time data visualization and custom reports.',
    role: 'Frontend Developer',
    tech: ['React', 'Chart.js', 'Tailwind CSS', 'REST API'],
    image: '📊',
    demo: '#',
    github: '#',
  },
  {
    id: 4,
    title: 'Social Media Feed',
    description: 'Infinite scroll social feed with likes, comments, and real-time notifications.',
    role: 'Frontend Developer',
    tech: ['Next.js', 'React Query', 'Tailwind', 'WebSocket'],
    image: '📱',
    demo: '#',
    github: '#',
  },
  {
    id: 5,
    title: 'Design System',
    description: 'Comprehensive component library with documentation and Storybook integration.',
    role: 'UI Developer',
    tech: ['React', 'Storybook', 'Tailwind CSS', 'TypeScript'],
    image: '🎨',
    demo: '#',
    github: '#',
  },
  {
    id: 6,
    title: 'Weather App',
    description: 'Beautiful weather application with location-based forecasts and interactive maps.',
    role: 'Frontend Developer',
    tech: ['React', 'Tailwind CSS', 'OpenWeather API', 'Mapbox'],
    image: '🌤️',
    demo: '#',
    github: '#',
  },
]

export function Projects() {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  }

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.5 },
    },
  }

  return (
    <section id="projects" className="py-20 px-4 sm:px-6 lg:px-8 bg-dark-secondary">
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="mb-16"
        >
          <h2 className="text-4xl sm:text-5xl font-bold mb-4">
            Featured <span className="bg-gradient-to-r from-accent to-blue-400 bg-clip-text text-transparent">Projects</span>
          </h2>
          <p className="text-gray-400 text-lg max-w-2xl">
            Showcase of my recent work across different domains and technologies.
          </p>
        </motion.div>

        {/* Projects Grid */}
        <motion.div
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
        >
          {projects.map((project) => (
            <motion.div
              key={project.id}
              variants={itemVariants}
              className="group bg-dark rounded-lg overflow-hidden border border-dark-tertiary hover:border-accent transition-all duration-300"
              whileHover={{ y: -8 }}
            >
              {/* Project Image */}
              <div className="h-48 bg-dark-tertiary flex items-center justify-center text-6xl group-hover:bg-dark-secondary transition-colors">
                {project.image}
              </div>

              {/* Project Content */}
              <div className="p-6">
                <h3 className="text-xl font-bold mb-2 group-hover:text-accent transition-colors">
                  {project.title}
                </h3>
                <p className="text-gray-400 text-sm mb-4">{project.description}</p>

                {/* Role */}
                <div className="mb-4">
                  <span className="text-xs text-accent font-semibold">{project.role}</span>
                </div>

                {/* Tech Stack */}
                <div className="flex flex-wrap gap-2 mb-6">
                  {project.tech.map((tech) => (
                    <span
                      key={tech}
                      className="px-3 py-1 text-xs bg-dark-tertiary text-gray-300 rounded-full"
                    >
                      {tech}
                    </span>
                  ))}
                </div>

                {/* Links */}
                <div className="flex gap-3">
                  <motion.a
                    href={project.demo}
                    className="flex-1 px-4 py-2 bg-accent text-dark font-semibold rounded text-sm hover:bg-blue-400 transition-colors flex items-center justify-center gap-2"
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    <ExternalLink size={16} /> Demo
                  </motion.a>
                  <motion.a
                    href={project.github}
                    className="flex-1 px-4 py-2 border border-accent text-accent font-semibold rounded text-sm hover:bg-accent/10 transition-colors flex items-center justify-center gap-2"
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    <Github size={16} /> Code
                  </motion.a>
                </div>
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  )
}
