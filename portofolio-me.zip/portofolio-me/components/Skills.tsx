'use client'

import { motion } from 'framer-motion'

const skills = [
  { category: 'Frontend', items: ['React', 'Next.js', 'TypeScript', 'Tailwind CSS'] },
  { category: 'UI/UX', items: ['Figma', 'Responsive Design', 'Animation', 'Accessibility'] },
  { category: 'Tools', items: ['Git', 'VS Code', 'Webpack', 'Docker'] },
  { category: 'Soft Skills', items: ['Problem Solving', 'Communication', 'Team Collaboration', 'Attention to Detail'] },
]

export function Skills() {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  }

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.5 },
    },
  }

  return (
    <section id="skills" className="py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="mb-16"
        >
          <h2 className="text-4xl sm:text-5xl font-bold mb-4">
            Skills & <span className="bg-gradient-to-r from-accent to-blue-400 bg-clip-text text-transparent">Expertise</span>
          </h2>
          <p className="text-gray-400 text-lg max-w-2xl">
            Technologies and skills I use to build modern web applications.
          </p>
        </motion.div>

        {/* Skills Grid */}
        <motion.div
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6"
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
        >
          {skills.map((skillGroup) => (
            <motion.div
              key={skillGroup.category}
              variants={itemVariants}
              className="bg-dark-secondary rounded-lg p-6 border border-dark-tertiary hover:border-accent transition-all duration-300"
              whileHover={{ y: -4 }}
            >
              <h3 className="text-lg font-bold mb-4 text-accent">
                {skillGroup.category}
              </h3>
              <ul className="space-y-3">
                {skillGroup.items.map((skill) => (
                  <li
                    key={skill}
                    className="text-gray-300 flex items-center gap-2"
                  >
                    <span className="w-2 h-2 bg-accent rounded-full"></span>
                    {skill}
                  </li>
                ))}
              </ul>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  )
}
